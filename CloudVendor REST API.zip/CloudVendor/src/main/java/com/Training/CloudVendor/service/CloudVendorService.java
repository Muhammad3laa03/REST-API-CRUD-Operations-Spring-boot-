package com.Training.CloudVendor.service;

import com.Training.CloudVendor.model.CloudVendor;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface CloudVendorService {

    public CloudVendor save(CloudVendor cloudVendor);
    public CloudVendor updateCloudVendor (CloudVendor cloudVendor);
    public String deleteCloudVendor (Integer vendorId);
    public CloudVendor getVendorDetails(Integer vendorId);
    public List<CloudVendor> getAllVendors();



}
