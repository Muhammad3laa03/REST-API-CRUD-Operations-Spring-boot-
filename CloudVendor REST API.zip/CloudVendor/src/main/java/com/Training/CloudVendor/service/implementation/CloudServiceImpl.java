package com.Training.CloudVendor.service.implementation;

import com.Training.CloudVendor.model.CloudVendor;
import com.Training.CloudVendor.repository.CloudVendorRepository;
import com.Training.CloudVendor.service.CloudVendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CloudServiceImpl implements CloudVendorService {

    @Autowired
    CloudVendorRepository cloudVendorRepository;

    @Override
    public CloudVendor  save(CloudVendor cloudVendor) {
        return this.cloudVendorRepository.save(cloudVendor);
    }

    @Override
    public CloudVendor updateCloudVendor(CloudVendor cloudVendor) {

        return cloudVendorRepository.save(cloudVendor);
    }

    @Override
    public String deleteCloudVendor(Integer vendorId) {
            cloudVendorRepository.deleteById(vendorId);
        return "Deleted";
    }

    public CloudVendor getVendorDetails(Integer vendorId) {

        Optional <CloudVendor> cloudVendor= cloudVendorRepository.findById(vendorId);
        return cloudVendor.orElse(null);
    }

    @Override
    public List<CloudVendor> getAllVendors() {

        return cloudVendorRepository.findAll();
    }
}
