package com.Training.CloudVendor.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name= "cloud_vendor_info")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CloudVendor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vendorId")
    private Integer vendorId;
    @Column(name = "vendorName")
    private String vendorName;
    @Column(name = "vendorAddress")
    private String vendorAddress;
    @Column(name = "vendorPhoneNumber")
    private String vendorPhoneNumber;


}
