package com.Training.CloudVendor.repository;

import com.Training.CloudVendor.model.CloudVendor;
import com.Training.CloudVendor.service.CloudVendorService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface CloudVendorRepository extends JpaRepository<CloudVendor, Integer> {
}
