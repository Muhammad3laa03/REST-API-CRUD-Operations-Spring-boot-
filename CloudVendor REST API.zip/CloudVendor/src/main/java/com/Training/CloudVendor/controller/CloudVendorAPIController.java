package com.Training.CloudVendor.controller;
import com.Training.CloudVendor.model.CloudVendor;
import com.Training.CloudVendor.service.CloudVendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/could-vendor")
public class CloudVendorAPIController
{
    @Autowired
    CloudVendorService cloudVendorService;
    CloudVendor cloudVendor;



    @PostMapping("/create-vendor")
    public CloudVendor Save (@RequestBody CloudVendor cloudVendor)
    {

        return this.cloudVendorService.save(cloudVendor);
    }
    @PutMapping("/update-vendor")
    public CloudVendor updateCloudVendor (@RequestBody CloudVendor cloudVendor)
    {

        return cloudVendorService.updateCloudVendor(cloudVendor);
    }
    @DeleteMapping("/delete-vendor=")
    public void deleteCloudVendor (@RequestParam("id") Integer vendorId)
    {

         cloudVendorService.deleteCloudVendor(vendorId);
    }
    @GetMapping("/get-vendor-details=")
    public CloudVendor getVendorDetails(@RequestParam("id") Integer vendorId)
    {
        return cloudVendorService.getVendorDetails(vendorId);
    }
    @GetMapping("/get-all-vendor-details")
    public List<CloudVendor> getAllVendors()
    {
        return cloudVendorService.getAllVendors();
    }


}
