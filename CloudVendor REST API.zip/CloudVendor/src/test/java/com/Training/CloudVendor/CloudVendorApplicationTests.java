package com.Training.CloudVendor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudVendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
